-- MySQL dump 10.15  Distrib 10.0.19-MariaDB, for Win32 (AMD64)
--
-- Host: localhost    Database: penjualan
-- ------------------------------------------------------
-- Server version	10.4.11-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `categories`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `categories` (
  `KategoriID` int(11) NOT NULL AUTO_INCREMENT,
  `NamaKategori` varchar(15) DEFAULT NULL,
  `Deskripsi` varchar(255) DEFAULT NULL,
  `Picture` varchar(40) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`KategoriID`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`KategoriID`, `NamaKategori`, `Deskripsi`, `Picture`, `created_at`, `updated_at`) VALUES (18,'Headset','Headset',NULL,'2020-02-15 13:05:52','0000-00-00 00:00:00'),(19,'Powerbank','Powerbank',NULL,'2020-02-15 13:06:06','0000-00-00 00:00:00'),(22,'Kabel Data','Kabel Data',NULL,'2020-02-15 13:06:43','0000-00-00 00:00:00'),(23,'Charger','Charger',NULL,'2020-02-15 15:08:06','0000-00-00 00:00:00');

--
-- Table structure for table `groups`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `groups` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `description` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`id`, `name`, `description`) VALUES (1,'admin','Administrator'),(2,'members','General User');

--
-- Table structure for table `login_attempts`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `login_attempts` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(45) NOT NULL,
  `login` varchar(100) NOT NULL,
  `time` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_attempts`
--


--
-- Table structure for table `pembelian`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `pembelian` (
  `transaksiID` varchar(30) NOT NULL,
  `totalharga` int(100) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`transaksiID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pembelian`
--

INSERT INTO `pembelian` (`transaksiID`, `totalharga`, `created_at`, `updated_at`) VALUES ('200216050642',53400000,'2020-02-16 17:06:42','0000-00-00 00:00:00'),('200217034455',1800000,'2020-02-17 03:44:55','0000-00-00 00:00:00');

--
-- Table structure for table `penjualan`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `penjualan` (
  `transaksiID` varchar(30) NOT NULL,
  `totalharga` int(100) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`transaksiID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `penjualan`
--

INSERT INTO `penjualan` (`transaksiID`, `totalharga`, `created_at`, `updated_at`) VALUES ('200216055003',178000,'2020-02-16 17:50:03','0000-00-00 00:00:00'),('200216055037',13000,'2020-02-16 17:50:37','0000-00-00 00:00:00');

--
-- Table structure for table `products`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `products` (
  `ProdukID` varchar(25) NOT NULL,
  `NamaProduk` varchar(40) DEFAULT NULL,
  `SupplierID` int(11) DEFAULT NULL,
  `KategoriID` int(11) DEFAULT NULL,
  `Satuan` varchar(20) DEFAULT NULL,
  `HargaBeli` float DEFAULT 0,
  `HargaJual` float NOT NULL,
  `Stok` smallint(6) DEFAULT 0,
  `Terjual` smallint(6) DEFAULT 0,
  `Reorder` smallint(6) DEFAULT 0,
  `Discontinued` tinyint(1) DEFAULT 0,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`ProdukID`),
  KEY `SupplierID` (`SupplierID`),
  KEY `KategoriID` (`KategoriID`),
  CONSTRAINT `products_ibfk_1` FOREIGN KEY (`SupplierID`) REFERENCES `suppliers` (`SupplierID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `products_ibfk_2` FOREIGN KEY (`KategoriID`) REFERENCES `categories` (`KategoriID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`ProdukID`, `NamaProduk`, `SupplierID`, `KategoriID`, `Satuan`, `HargaBeli`, `HargaJual`, `Stok`, `Terjual`, `Reorder`, `Discontinued`, `created_at`, `updated_at`) VALUES ('200216024747','Headset Robot RE101',33,18,'PCS',16000,18000,100,0,20,0,'2020-02-16 14:51:26','2020-02-17 03:44:51'),('200216025247','Headset Robot RE501',33,18,'PCS',32000,48000,0,0,20,0,'2020-02-16 14:53:16','0000-00-00 00:00:00'),('200216025345','Headset Robot G10',33,18,'PCS',98000,138000,0,0,20,0,'2020-02-16 14:54:18','0000-00-00 00:00:00'),('200216025428','Charger Robot C40s',33,23,'PCS',66000,78000,0,0,20,0,'2020-02-16 14:54:52','0000-00-00 00:00:00'),('200216025522','Charger Robot RTK2',33,23,'PCS',18000,28000,0,0,20,0,'2020-02-16 14:55:41','0000-00-00 00:00:00'),('200216031103','Powerbank Vivan K10',33,19,'PCS',198000,218000,0,0,20,0,'2020-02-16 15:11:51','2020-02-16 15:18:33'),('200216031200','Powerbank Vivan A10',33,19,'PCS',178000,188000,0,0,20,0,'2020-02-16 15:12:18','2020-02-16 15:36:37'),('200216031241','Powerbank Vivan W10',33,19,'PCS',199000,238000,0,0,20,0,'2020-02-16 15:13:07','2020-02-16 15:18:48'),('200216031413','Headset Vivan T100',33,18,'PCS',232000,238000,0,0,20,0,'2020-02-16 15:14:35','2020-02-16 15:19:07'),('200216031439','Charger Vivan Quallcom',33,23,'PCS',78000,98000,0,0,20,0,'2020-02-16 15:15:42','2020-02-16 15:19:14'),('200216031553','Kabel Data Vivan CSM100',33,22,'PCS',8000,13000,99,1,20,0,'2020-02-16 15:16:11','2020-02-16 17:50:33'),('200216031642','Kabel Data Vivan CSL100',33,22,'PCS',13000,20000,0,0,20,0,'2020-02-16 15:17:04','2020-02-16 15:19:26'),('200216050527','Powerbank Robot RT130',33,19,'PCS',150000,178000,299,1,20,0,'2020-02-16 17:05:52','2020-02-16 17:50:01');

--
-- Table structure for table `subtransaksi`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `subtransaksi` (
  `subtransaksiID` varchar(30) NOT NULL,
  `ProdukID` varchar(30) NOT NULL,
  `transaksiID` varchar(30) NOT NULL,
  `jumlahbeli` int(100) NOT NULL,
  `totalharga` int(100) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`subtransaksiID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subtransaksi`
--

INSERT INTO `subtransaksi` (`subtransaksiID`, `ProdukID`, `transaksiID`, `jumlahbeli`, `totalharga`, `created_at`, `updated_at`) VALUES ('200216050636','200216050527','200216050642',300,53400000,'2020-02-16 17:06:36','0000-00-00 00:00:00'),('200216055001','200216050527','200216055003',1,178000,'2020-02-16 17:50:01','0000-00-00 00:00:00'),('200216055033','200216031553','200216055037',1,13000,'2020-02-16 17:50:33','0000-00-00 00:00:00'),('200217034451','200216024747','200217034455',100,1800000,'2020-02-17 03:44:51','0000-00-00 00:00:00');

--
-- Table structure for table `suppliers`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `suppliers` (
  `SupplierID` int(11) NOT NULL AUTO_INCREMENT,
  `NamaPerusahaan` varchar(40) DEFAULT NULL,
  `NamaKontak` varchar(30) DEFAULT NULL,
  `Alamat` varchar(60) DEFAULT NULL,
  `Kota` varchar(15) DEFAULT NULL,
  `KodePos` varchar(10) DEFAULT NULL,
  `Telephone` varchar(24) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`SupplierID`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`SupplierID`, `NamaPerusahaan`, `NamaKontak`, `Alamat`, `Kota`, `KodePos`, `Telephone`, `Email`, `created_at`, `updated_at`) VALUES (32,'PT VGEN ASTRO','Subarja','Denggung, Sleman','Yogyakarta','515263','085711489366','vgenastro@gmail.com','2020-02-15 11:22:05','0000-00-00 00:00:00'),(33,'PT WOOK INDONESIA','Reno','JL. Ring Road barat, Demak Ijo','Yogyakarta','454696','0895401205135','wookindo@gmail.com','2020-02-15 11:23:09','0000-00-00 00:00:00'),(34,'PT FRIWOL INDONESA','Iwan','JL. Gejayan No 56, Yogyakarta','Yogyakarta','587898','081305983465','renoasing@gmail.com','2020-02-15 11:26:24','0000-00-00 00:00:00'),(35,'PT FANTECH INDONESIA','Bagus','Jakarta Selatan','DKI Jakarta','77145','08596324589','karolinasejahtera@co.id','2020-02-15 13:05:36','2020-02-15 15:05:53'),(36,'PT REXUS INDONESIA','Roni','Magelang, Jawa Tengah','Magelang','99876','089765342887','rexusid@gmail.com','2020-02-15 15:06:48','0000-00-00 00:00:00');

--
-- Table structure for table `tempo`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `tempo` (
  `subtransaksiID` varchar(30) NOT NULL,
  `ProdukID` varchar(30) NOT NULL,
  `harga` int(100) NOT NULL,
  `jumlahbeli` int(100) NOT NULL,
  `totalharga` int(100) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`subtransaksiID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tempo`
--


--
-- Table structure for table `users`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(45) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `salt` varchar(255) DEFAULT NULL,
  `email` varchar(254) NOT NULL,
  `activation_code` varchar(40) DEFAULT NULL,
  `forgotten_password_code` varchar(40) DEFAULT NULL,
  `forgotten_password_time` int(11) unsigned DEFAULT NULL,
  `remember_code` varchar(40) DEFAULT NULL,
  `created_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp(),
  `last_login` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  `active` tinyint(1) unsigned DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `ip_address`, `username`, `password`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `forgotten_password_time`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`) VALUES (1,'127.0.0.1','administrator','$2a$07$SeBknntpZror9uyftVopmu61qg0ms8Qv1yV6FG.kQOSM.9QhmTo36','','admin@admin.com','',NULL,NULL,'CTnVm65J3GP5CF8gvEwdnO','2020-02-20 09:46:29','2020-02-20 03:46:29',1,'Admin','istrator','ADMIN','0'),(2,'::1','member','$2y$08$v7gDpuD2TauK2sCgZKtBRuJD9URB7GYjiFsCRjKWPZQOjwJ046XT.',NULL,'member@member.com',NULL,NULL,NULL,NULL,'2020-02-16 23:49:27','2020-02-16 17:49:27',1,'member',NULL,'',''),(3,'::1','admin','$2y$08$QcxaOTidK3Zz5CQdSmvBU.MueV72NfRCmjxwdR5hpugRMBoKsFrFG',NULL,'tonianton@gmail.com',NULL,NULL,NULL,NULL,'2020-02-15 11:02:57',NULL,1,'anton',NULL,'IT','081903908462');

--
-- Table structure for table `users_groups`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `users_groups` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `group_id` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uc_users_groups` (`user_id`,`group_id`),
  KEY `fk_users_groups_users1_idx` (`user_id`),
  KEY `fk_users_groups_groups1_idx` (`group_id`),
  CONSTRAINT `fk_users_groups_groups1` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `fk_users_groups_users1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_groups`
--

INSERT INTO `users_groups` (`id`, `user_id`, `group_id`) VALUES (4,1,1),(3,2,2),(5,3,1);
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-02 21:54:11
